Python client for kubernetes http://kubernetes.io/


